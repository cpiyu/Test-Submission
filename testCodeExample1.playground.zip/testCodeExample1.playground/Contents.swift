import UIKit

func solve<T: Hashable & Comparable>(_ array1: [T], _ array2: [T]) -> [T] {
    var count1 = [T: Int]()
    var count2 = [T: Int]()
   
    for item in array1 {
        count1[item, default: 0] += 1
    }
   
    for item in array2 {
        count2[item, default: 0] += 1
    }
   
    var result = [T]()
   
    for item in count2.keys {
        if count1[item, default: 0] != count2[item, default: 0] {
            result.append(item)
        }
    }
   
    return result.sorted()
}

let array1 = [8, 8, 7, 2, 1, 7, 9]
let array2 = [14, 8, 2, 7, 7]

print(solve(array1, array2)) 
